print " Executing ur_training/__init__.py"
from start_training_v2 import main
print " Executed ur_training/__init__.py"
