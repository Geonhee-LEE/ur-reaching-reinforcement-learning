print "   Executing ur_training/algorithm/__init__.py"
from qlearn import *
from sarsa import *
from simple_qlearn import *
print "   Executed ur_training/algorithm/__init__.py"
